﻿using $ext_safeprojectname$Services.Db.Entities;


namespace $safeprojectname$.DTO.V1.MyAwesomeProducts;


public class DeleteProductResponse
{
    
}
