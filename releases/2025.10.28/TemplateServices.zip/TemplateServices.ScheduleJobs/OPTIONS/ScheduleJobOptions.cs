﻿

namespace $safeprojectname$.Options;


public class ScheduleJobOptions
{
    /// <summary>
    /// Включена ли указанная задача?
    /// </summary>
    public bool EnableJob { get; set; }
}