﻿using AutoMapper;


namespace $safeprojectname$.Jobs.ReturnClaimsImport;


public class MyAwesomeProductsImportMapperProfile : Profile
{
    public MyAwesomeProductsImportMapperProfile()
    {
    }
}
