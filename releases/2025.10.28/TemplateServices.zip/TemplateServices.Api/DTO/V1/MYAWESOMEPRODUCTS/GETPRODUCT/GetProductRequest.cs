﻿namespace $safeprojectname$.DTO.V1.MyAwesomeProducts;


public class GetProductRequest : ApiRequest
{
    /// <summary>
    /// ID Продукта
    /// </summary>
    public long Id { get; set; }
}