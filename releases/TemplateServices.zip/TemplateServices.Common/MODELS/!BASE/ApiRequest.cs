﻿

namespace $safeprojectname$.Models.Base;


/// <summary>
/// Запрос к API
/// </summary>
public abstract class ApiRequest
{
    public ApiRequest()
    { }
}