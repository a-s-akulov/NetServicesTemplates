﻿using $ext_safeprojectname$Services.Db.Entities;


namespace $safeprojectname$.DTO.V1.MyAwesomeProducts;


public class AddOrUpdateProductResponse
{
    /// <summary>
    /// Обновленный продукт
    /// </summary>
    public MyAwesomeProduct Product { get; set; }
}
