﻿using System.ComponentModel;


namespace $safeprojectname$.Auth;


/// <summary>
/// Действия приложения для авторизации
/// </summary>
public enum enAppAction
{
    // "Пустая" роль - роль не указана
    None = 0,

    // Partners
    //[Description("PartnersRead")] PartnersRead = 1001,
}